plugins {
	eclipse
	idea
	id("junitbuild.java-toolchain-conventions")
	id("junitbuild.spotless-conventions")
}
