/**
 * Demo code for a WebServer extension.
 */

package example.registration;
